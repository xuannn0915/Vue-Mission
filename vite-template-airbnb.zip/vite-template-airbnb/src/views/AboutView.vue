<template>
  <h1>This is About page.</h1>
  <RouterLink to="/">Home</RouterLink> |
  <RouterLink to="/about">About</RouterLink>
</template>

<script>
export default {
};
</script>

<style scoped>
</style>
